#include <iostream>
#include "PilhaEncad.h"
#include "FilaEncad.h"

using namespace std;

int* inverte(int *vet, int n)
{
    int* vet2 =new int[n];
    PilhaEncad P;


    for(int i=0; i<n; i++)
        {P.empilha(vet[i]);
            P=P // PArei aqui
        }




}


int main()
{
    /// TESTE COM PILHA
    PilhaEncad p;
    int vet[0];
    int tam=0;


    for(int i = 0; i < 5; i++)
        p.empilha(i);
    cout << "Pilha apos inserir 5 valores" << endl;
    p.imprime();
    cout<< "Tamanho da lista: " << p.tamanho() << endl;

    for(int i = 20; i < 25; i++)
        p.empilha(i);
    cout << "Pilha apos inserir mais 5 valores" << endl;
    p.imprime();
    cout<< "Tamanho da lista: " << p.tamanho() << endl;

    /// TESTE COM FILA

    FilaEncad f;
    for(int i=0; i<5; i++)
        f.enfileira(i);
    cout << "Fila apos inserir 5 valores" << endl;
    f.imprime();

    for(int i = 20; i < 25; i++)
        f.enfileira(i);
    cout << "Fila apos inserir mais 5 valores" << endl;
    f.imprime();

    //----------------------------------------- QUESTÃO 3 --------------------------------------------//

    cout << "Determine o numeros de nos do vetor 1 que sera invertido" << endl;
    cin >> tam;

    for (int i=0; i<tam; i++)
    {
        cout << "Digite o elemento " << i+1 << " do novo vetor" << endl;
        cin >> vet[i];

    }

    cout << inverte(vet, tam)<< endl;




    return 0;
}
