
#ifndef ALUNO_H_INCLUDED
#define ALUNO_H_INCLUDED
#include <string>
using namespace std;


class Aluno
{
private:

    int idade;
    string nome, matricula;
    double notas[7];
    bool freq[7];

public:

    Aluno(string n, string mat);
    ~Aluno();


    void leNotas();
    double calculaMedia();


    string getNome() {return nome;}
    void setNome(string name) {nome = name;}

    int getIdade() {return idade;}
    void setIdade(int age) {idade = age;}

    string getMatricula() {return matricula;}
    void setMatricula(string mat) {nome = mat;}

    void imprime();

    void leFreq();
};

#endif // ALUNO_H_INCLUDED
