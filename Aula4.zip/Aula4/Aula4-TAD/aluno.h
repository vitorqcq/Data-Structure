#ifndef ALUNO_H_INCLUDED
#define ALUNO_H_INCLUDED
#include <string>
using namespace std;


class Aluno
{
private:

int idade;
string nome[50], matricula[50];
double notas[7];

public:

 Aluno(string n, string mat);
 ~Aluno();


 void leNotas ();
 double calculaMedia ();

};

#endif // ALUNO_H_INCLUDED
