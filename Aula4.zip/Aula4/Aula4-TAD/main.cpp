#include <iostream>
#include "Aluno.h"

using namespace std;

int main()
{
    Aluno a("Vitor Queiroz", "467934590");
  a.leNotas();
  a.setIdade(21);
  a.leFreq();
  a.imprime();


    cout << " Media " << a.calculaMedia() << endl;
    return 0;
}
