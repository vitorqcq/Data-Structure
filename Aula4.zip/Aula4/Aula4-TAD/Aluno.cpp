#include <iostream>
#include "Aluno.h"
using namespace std;

Aluno::Aluno (string n, string mat)
{
    nome = n;
    matricula = mat;
}

Aluno::~Aluno() {}

void Aluno::leNotas()
{
    for(int i=0; i<7; i++)
    {

        cout << "Digite a nota " << i << ": "<< endl;
        cin >> notas[i];
    }


}

double Aluno::calculaMedia()
{
    double media, soma;
    media = soma = 0;

    for(int j = 0; j<7; j++)
    {
        soma += notas[j];

    }
    media = soma/7.0;

    return media;
}

void Aluno::imprime()
{
    double media = calculaMedia();

    cout << endl;
    cout << "Nome: " << getNome() << endl;
    cout <<"Idade: " << getIdade() << endl;
    cout << "Matricula: " << getMatricula() << endl;
    cout << "Media: " << media << endl;

    if (media >= 60)
    {
        cout <<"Aprovado com media final em disciplinas" << endl;
    }


        for (int i=0; i<7; i++)
        {
            if (notas[i] >=60 && freq[i])
                cout << "Aprovado" << endl;

            else
                cout << "Reprovado" << endl;
        }




}

void Aluno::leFreq()
{
    for(int k=0; k<7; k++)
    {

        cout << "Digite a frequencia " << k << ": "<< endl;
        int f;
        cin >> f;

        if (f==1)
            freq[k] = true;

        else
            freq[k] = false;

        cout << endl;
    }


}
