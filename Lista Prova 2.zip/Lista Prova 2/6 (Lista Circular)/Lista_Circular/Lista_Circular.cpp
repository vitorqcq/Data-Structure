#include <iostream>
#include <stdlib.h>
#include "Lista_Circular.h"

void Lista_Circular::insereInicio(int val)
{
	No_Duplo *p = new No_Duplo();
	p->setInfo(val);
	p->setProx(primeiro);
	p->setAnt(ultimo);

	primeiro->setAnt(p);
	ultimo->setProx(p);





}

