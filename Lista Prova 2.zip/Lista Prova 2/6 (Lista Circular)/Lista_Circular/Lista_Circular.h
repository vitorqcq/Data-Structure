#ifndef LISTA_CIRCULAR_H_INCLUDED
#define LISTA_CIRCULAR_H_INCLUDED
#include "NoDuplo.h"
#endif // LISTA_CIRCULAR_H_INCLUDED

class Lista_Circular
{
public:

	Lista_Circular();
	~Lista_Circular();

	bool busca(int val);
	void insereInicio(int val);
	void insereFinal(int val);
	void RemoveInicio();
	void RemoveFinal();

private:
	NoDuplo *primeiro;
	NoDuplo *ultimo;
	int n;

};
