#include <iostream>
#include <stdlib.h>
#include "No_Duplo.h"

No_Duplo::No_Duplo() {}

No_Duplo::~No_Duplo() {}

void No_Duplo::setAnt(){ ant = p;}

void No_Duplo::setProx(){prox = p;}

void No_Duplo::setInfo(){info = val;}


