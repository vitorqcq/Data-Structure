#ifndef NO_DUPLO_H_INCLUDED
#define NO_DUPLO_H_INCLUDED
#endif // NO_DUPLO_H_INCLUDED

class No_Duplo
{
public:
    No_Duplo();
    ~No_Duplo();

    void setAnt (No_Duplo *p);
    void setProx (No_Duplo *p);
    void setInfo(int val);

    No_Duplo *getAnt();
    No_Duplo *getProx();
    int getInfo();

private:
    No_Duplo *ant;  // ponteiro para anterior
    int info; //informacao
    No_Duplo *prox;  //ponteiro para proximo

};
