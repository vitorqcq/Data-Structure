#include <iostream>
#include "ArvBin.h"
using namespace std;

int main()
{
    ArvBin *raiz = new ArvBin();
    ArvBin *a1 = new ArvBin();
    ArvBin *a2 = new ArvBin();
    ArvBin *a3 = new ArvBin();
    ArvBin *a4 = new ArvBin();
    ArvBin *a5 = new ArvBin();
    ArvBin *a6 = new ArvBin();
    ArvBin *a7 = new ArvBin();
    ArvBin *a8 = new ArvBin();
    ArvBin *a9 = new ArvBin();
    ArvBin *nula = new ArvBin();


    a1->cria(-2,nula,nula);
    a2->cria(3,nula,nula);
    a3->cria(8,nula,nula);
    a4->cria(7,nula,nula);



    a5->cria(10, a1,a2);
    a6->cria(14,a3, a4);
    a7->cria(-8,nula,nula);

    a8->cria(15,a5,nula);
    a9->cria(11,a6,a7);

    raiz->cria(2,a8,a9);

    raiz->preOrdem();

        cout << endl;

    cout<< "Numero de folhas impares: "<< raiz->ContaFolhasImpares() << endl;

    cout<< "Numero de elementos impares: "<< raiz->contaImpar() << endl;

    raiz->ImprimeNivel (3);

    cout<< "Media do nivel 3: "<< raiz->mediaNivel(3)<< endl;

       cout << endl;

    delete raiz;



    return 0;
}
