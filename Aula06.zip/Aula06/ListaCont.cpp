#include <iostream>
#include <cstdlib>
#include "Ponto.h"
#include "ListaCont.h"

using namespace std;

ListaCont::ListaCont(int tam)
{
    cout << "Criando objeto ListaCont" << endl;
    max = tam;
    n = 0;
    vet = new int[max];
}

ListaCont::~ListaCont()
{
    cout << "Destruindo objeto ListaCont" << endl;
    delete [] vet;
}

int ListaCont::get(int k)
{
    if(k >= 0 && k < n)
        return vet[k];
    else
    {
        cout << "ERRO: Indice invalido!" << endl;
        exit(1);
    }
}

void ListaCont::set(int k, int val)
{
    if(k >= 0 && k < n)
        vet[k] = val;
    else
    {
        cout << "ERRO: Indice invalido!" << endl;
        exit(1);
    }
}

void ListaCont::insereFinal(int val)
{
    if(n == max)
    {
        cout << "ERRO: Vetor Cheio!" << endl;
        exit(1);
    }
    vet[n] = val;
    n = n + 1;
}

void ListaCont::removeFinal()
{
    if(n == 0)
    {
        cout << "ERRO: Lista Vazia!" << endl;
        exit(1);
    }
    n = n - 1;
}

void ListaCont::insereK(int k, int val)
{
    if(n == max)
    {
        cout << "ERRO: Vetor Cheio!" << endl;
        exit(1);
    }
    if(k >= 0 && k < n)
    {
        for(int i = n-1; i >= k; i--)
            vet[i+1] = vet[i];
        vet[k] = val;
        n = n + 1;
    }
    else
    {
        cout << "ERRO: Indice invalido!" << endl;
        exit(1);
    }
}

void ListaCont::removeK(int k)
{
    if(k >= 0 && k < n)
    {
        for(int i = k; i < n-1; i++)
            vet[i] = vet[i+1];
        n = n - 1;
    }
    else
    {
        cout << "ERRO: Indice invalido!" << endl;
        exit(1);
    }
}

void ListaCont::insereInicio(int val)
{
    if(n == 0)
    {
        //lista vazia. Sera o unico no da lista
        vet[n] = val;
        n = n + 1;
    }
    else
        insereK(0, val);
}

void ListaCont::removeInicio()
{
    removeK(0);
}

void ListaCont::imprime()
{
    for (int i=0; i<max; i++)
    {
        cout<< vet[i]<< ", ";
    }
    cout<< endl;
}

bool ListaCont :: troca (int posicao1, int posicao2 )
{
    float a, b;
    if (posicao1<max && posicao1>=0 && posicao2<max && posicao2>=0)
    {
        a= get(posicao1);
        b=get(posicao2);

        set(posicao1, b);
        set(posicao2, a);
        imprime();
        return true;
    }

    else
        return false;

}

bool ListaCont :: aumentaCapacidade (int novoMax )
{
    //Criando vetor auxiliar
    int *aux_vet = new int [novoMax];

    //Verifica validade do novo tamanho e executa opera��es
    if (novoMax > max)
    {

        for (int i=0; i<max; i++) //Copia valores para vetor auxiliar
            aux_vet[i] = vet[i];

        //Deleta e cria vetor "vet" com novo tamanho
        //delete [] vet;
        //vet = new int [novoMax];
vet[novoMax];
        //Copia valores do vetor auxiliar para o vetor original recriado
        for (int j=0; j< max; j++)
            vet[j] = aux_vet[j];

        delete [] aux_vet;

        for (int a=max; a<=novoMax; a++)
            vet[a] = 0;


for (int k=0; k<novoMax; k++)
    cout << vet[k] << ", ";

    cout << endl;

        return true;
    }

    else
        return false;

}



